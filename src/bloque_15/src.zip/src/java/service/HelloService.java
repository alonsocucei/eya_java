package service;

/**
 * @author alonsocucei
 */
public class HelloService {

    public String sayHello(String name) {
        return "Hello " + name + "!";
    }
}
